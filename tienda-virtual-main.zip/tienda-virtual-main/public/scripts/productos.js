const productos1 = [    {
        "id": "1",
        "publicadoPor": "Publicado por Juan García",
        "nombre": "Aceite de Cocina",
        "precio": "2000",
        "descuento": "0.30",
        "imagen": "./images/products/aceitedeCocina/aceite usado.jpg"
    },
    {
        "id": "2",
        "publicadoPor": "Publicado por María Rodríguez",
        "nombre": "Cables",
        "precio": "150000",
        "descuento": "0.30",
        "imagen": "./images/products/electronicos/cables y cargadores.jpg"
    },
    {
        "id": "3",
        "publicadoPor": "Publicado por Pedro Martínez",
        "nombre": "Computadores",
        "precio": "500000",
        "descuento": "0.30",
        "imagen": "./images/products/electronicos/computadoras.jpg"
    },
    {
        "id": "4",
        "publicadoPor": "Publicado por Ana López",
        "nombre": "Tablets",
        "precio": "600000",
        "descuento": "0.30",
        "imagen": "./images/products/electronicos/tablets.jpg"
    },
    {
        "id": "5",
        "publicadoPor": "Publicado por Luisa Pérez",
        "nombre": "Moviles",
        "precio": "600000",
        "descuento": "0.30",
        "imagen": "./images/products/electronicos/moviles.jpeg"
    },
    {
        "id": "6",
        "publicadoPor": "Publicado por Carlos Sánchez",
        "nombre": "Envases de metal",
        "precio": "2000",
        "descuento": "0.30",
        "imagen": "./images/products/metal/envases de metal.jpg"
    },
    {
        "id": "7",
        "publicadoPor": "Publicado por Sofía Romero",
        "nombre": "Latas de aluminio",
        "precio": "3000",
        "descuento": "0.30",
        "imagen": "./images/products/metal/latas de aluminio.jpg"
    },

    {
        "id": "8",
        "publicadoPor": "Publicado por José González",
        "nombre": "Muebles en desuso",
        "precio": "2000",
        "descuento": "0.30",
        "imagen": "./images/products/Muebles y Electrodomesticos/muebles en desuso.jpg"
    },
    {
        "id": "9",
        "publicadoPor": "Publicado por Laura Díaz",
        "nombre": "Electrodomesticos en desuso",
        "precio": "3000",
        "descuento": "0.30",
        "imagen": "./images/products/Muebles y Electrodomesticos/electrodomesticos en desuso.jpg"
    },
    {
        "id": "10",
        "publicadoPor": "Publicado por Diego Fernández",
        "nombre": "Neumaticos usados",
        "precio": "700",
        "descuento": "0.30",
        "imagen": "./images/products/Neumaticos/neumaticos usados.jpg"
    },
    {
        "id": "11",
        "publicadoPor": "Publicado por Elena Moreno",
        "nombre": "Filtros de cafe",
        "precio": "1200",
        "descuento": "0.30",
        "imagen": "./images/products/Organicos/filtros de cafe.jpg"
    },
    {
        "id": "12",
        "publicadoPor": "Publicado por Miguel Álvarez",
        "nombre": "Residuos de jardin",
        "precio": "300",
        "descuento": "0.30",
        "imagen": "./images/products/Organicos/residuos de jardin.jpg"
    },
    {
        "id": "13",
        "publicadoPor": "Publicado por Lucía Gutiérrez",
        "nombre": "Papel de cocina",
        "precio": "800",
        "descuento": "0.30",
        "imagen": "./images/products/Organicos/papel de cocina.jpg"
    },
    {
        "id": "14",
        "publicadoPor": "Publicado por Antonio Torres",
        "nombre": "Restos de comida",
        "precio": "500",
        "descuento": "0.30",
        "imagen": "./images/products/Organicos/restos de comida.jpg"
    },
    {
        "id": "15",
        "publicadoPor": "Publicado por Isabel Ruiz",
        "nombre": "Cajas de carton",
        "precio": "4000",
        "descuento": "0.30",
        "imagen": "./images/products/Papelycarton/cajas de carton.jpg"
    }, 
    {
        "id": "16",
        "publicadoPor": "Publicado por Fernando Ramos",
        "nombre": "Carton corrugado",
        "precio": "4000",
        "descuento": "0.30",
        "imagen": "./images/products/Papelycarton/carton corrugado.jpg"
    },
    {
        "id": "17",
        "publicadoPor": "Publicado por Carmen Ortiz",
        "nombre": "Papel de colores",
        "precio": "6000",
        "descuento": "0.30",
        "imagen": "./images/products/Papelycarton/papel color.jpg"
    },
    {
        "id": "18",
        "publicadoPor": "Publicado por Pablo Medina",
        "nombre": "Papel blanco",
        "precio": "5000",
        "descuento": "0.30",     
        "imagen": "./images/products/Papelycarton/papelblanco.jpg"
    },
    {
        "id": "19",
        "publicadoPor": "Publicado por Rosa Castro",
        "nombre": "Revistas",
        "precio": "3000",
        "descuento": "0.30",
        "imagen": "./images/products/Papelycarton/revistas periodicos.jpg"
    },
    {
        "id": "20",
        "publicadoPor": "Publicado por Javier Jiménez",
        "nombre": "Baterias",
        "precio": "200000",
        "descuento": "0.30",
        "imagen": "./images/products/Pilasybaterias/baterias de dispositivos electronicos.png"
    },
    {
        "id": "21",
        "publicadoPor": "Publicado por Beatriz Navarro",
        "nombre": "Pilas Recargables",
        "precio": "100000",    
        "descuento": "0.30",
        "imagen": "./images/products/Pilasybaterias/pilas recargables.jpg"
    },

    {
        "id": "22",
        "publicadoPor": "Publicado por Manuel Bravo",
        "nombre": "Pilas alcalinas",
        "precio": "50000",
        "descuento": "0.30",
        "imagen": "./images/products/Pilasybaterias/pilas alcalinas.jpeg"
    },
    {
        "id": "23",
        "publicadoPor": "Publicado por Eva Molina",
        "nombre": "Bolsas de plastico",
        "precio": "1200",
        "descuento": "0.30",
        "imagen": "./images/products/Plastico/bolsas de plastico.jpg"
    },
    {
        "id": "24",
        "publicadoPor": "Publicado por Alejandro Delgado",
        "nombre": "Botellas de plastico",
        "precio": "2000",
        "descuento": "0.30",
        "imagen": "./images/products/Plastico/botellas de plastico.jpg"
    },
    {
        "id": "25",
        "publicadoPor": "Publicado por Clara Suárez",
        "nombre": "Envoltorios de alimento",
        "precio": "1600",
        "descuento": "0.30",
        "imagen": "./images/products/Plastico/envoltorios de alimentos.jpg"
    },
    {
        "id": "26",
        "publicadoPor": "Publicado por Raúl Ortega",
        "nombre": "Productos de limpieza",
        "precio": "1600",
        "descuento": "0.30",
        "imagen": "./images/products/Plastico/productos de limpieza.jpg"
    },

    {
        "id": "27",
        "publicadoPor": "Publicado por Marina Herrera",
        "nombre": "Pinturas y disolventes",
        "precio": "15000",
        "descuento": "0.30",
        "imagen": "./images/products/Residuospeligrosos/pinturas y disolventes.jpg"
    },
    {
        "id": "28",
        "publicadoPor": "Publicado por Jorge Flores",
        "nombre": "Productos quimicos",
        "precio": "14000",
        "descuento": "0.30",
        "imagen": "./images/products/Residuospeligrosos/productos quimicos domesticos.jpg"
    },
    {
        "id": "29",
        "publicadoPor": "Publicado por Nuria Álvarez",
        "nombre": "Ropa de cama",
        "precio": "20000",
        "descuento": "0.30",
        "imagen": "./images/products/Textiles/ropa de cama.jpg"
    },
    {
        "id": "30",
        "publicadoPor": "Publicado por David Muñoz",
        "nombre": "Ropa en buen estado",
        "precio": "8000",
        "descuento": "0.30",
        "imagen": "./images/products/Textiles/ropa en buen estado.jpg"
    },
    {
        "id": "31",
        "publicadoPor": "Publicado por Paula Vázquez",
        "nombre": "Ropa en mal estado",
        "precio": "2000",
        "descuento": "0.30",
        "imagen": "./images/products/Textiles/ropa en mal estado.jpg"
    },
    {
        "id": "32",
        "publicadoPor": "Publicado por Alberto Cordero",
        "nombre": "Textiles del hogar",
        "precio": "6000",
        "descuento": "0.30",
        "imagen": "./images/products/Textiles/textiles del hogar.jpg"
    },
    {
        "id": "33",
        "publicadoPor": "Publicado por Silvia Blanco",
        "nombre": "Envases de vidrio",
        "precio": "1000",
        "descuento": "0.30",
        "imagen": "./images/products/Vidrio/envases alimento de vidrio.jpg"
    },
    {
        "id": "34",
        "publicadoPor": "Publicado por Rubén Cabello",
        "nombre": "Frascos de vidrio",
        "precio": "1000",
        "descuento": "0.30",
        "imagen": "./images/products/Vidrio/frascos de vidrio.jpg"
    },
    {
        "id": "35",
        "publicadoPor": "Publicado por Lorena Santos",
        "nombre": "Botellas de vidrio",
        "precio": "800",    
        "descuento": "0.30",
        "imagen": "./images/products/Vidrio/Botellas de vidrioo.jpg"
    },
    {
        "id": "36",
        "publicadoPor": "Publicado por Francisco Reyes",
        "nombre": "Envases de metal",
        "precio": "2000",    
        "descuento": "0.30",
        "imagen": "./images/products/Metal/latas de alimento.jpg"
    },
]