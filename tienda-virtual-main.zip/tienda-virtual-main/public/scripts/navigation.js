if ( location.pathname.endsWith('/index') || location.pathname.endsWith('/')){
    inicioPagina();
    btnBuscar.addEventListener('click',buscarMostrarProducto);
}

if ( location.pathname.endsWith('/login')){
    btnSubmit.addEventListener('click', validarLogin);
}

if ( location.pathname.endsWith('/pagina')){
    btnBuscar.addEventListener('click',buscarMostrarProducto);
}

if(location.pathname.endsWith('/carrito')){
    paginaCarrito();
}

if(location.pathname.endsWith('/detalle')) {
    agregarDetalleProducto(localStorage.getItem('idProducto'));
}

if(location.pathname.endsWith('/detalle_pagina')) {
    agregarDetalleProducto(localStorage.getItem('idProducto'));
}

if ( location.pathname.endsWith('/inventario') || location.pathname.endsWith('/')){
    inicioPagina();
    btnBuscar.addEventListener('click',buscarMostrarProducto);
}
if ( location.pathname.endsWith('/login-admin')){
    btnSubmit.addEventListener('click', validarLoginAdmin);
}

if ( location.pathname.endsWith('/prueba') || location.pathname.endsWith('/')){
    inicioPagina();
    btnBuscar.addEventListener('click',contenedorProdcuto);
}

