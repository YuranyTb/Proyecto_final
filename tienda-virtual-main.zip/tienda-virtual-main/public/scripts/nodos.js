// Elementos
const filaCatalogoProd = document.querySelector('#row');// Representa un elemento con el ID
const contenedor = document.querySelector('#contenedor');
const btnBuscar = document.querySelector('#btnBuscar');// Representa un botón que se puede seleccionar con el ID 
const inputBuscar = document.querySelector('#inputBuscar');// Representa un campo de entrada de texto que se puede seleccionar con el ID 
//Login
const inputCorreoLogin = document.querySelector('#correo');
const inputContrasenaLogin = document.querySelector('#contrasena');
const btnSubmit = document.querySelector('#btnSubmit');
//Carrito
const cantidadProductosCarrito = document.querySelector('#cantidadProductosCarrito');
const btnCarrito = document.querySelector('#verCarrito');
const contenedorCarritoPrincipal = document.querySelector('#contenedorCarritoPrincipal');
//Estos nodos pueden ser utilizados para acceder y manipular elementos específicos







