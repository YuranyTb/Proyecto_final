//Usuarios registrados

function inicioPagina() {
    agregarCatalogo1();
}

//Cantidad de productos en el menu de navegacion
document.querySelector('.cart--quantity').textContent = calcularCantidadTotal();

// Función para agregar el catalogo a la web
function agregarCatalogo() {
    var productos = "";//Cadena vacia//
    fetch('http://localhost:3000/consultar_productos')//Solicitud al servidor local
        .then(response => { // Función de devolución de llamada, se ejecuta cuando la solicitud a la url se completa con exito.
            if (!response.ok) { // Si la solicitud fue exitosa, si la propiedad ok de la respuesta es falsa arroja msj
                throw new Error('No se pudo completar la solicitud');
            }
            return response.json();// Si la solicitud fue exitosa, convierte la respuesta en JSON, intercambio de datos, envia y recibe datos entre el servidor y cliente.
        })
        .then(data => { // Manejador de exito (callback) se ejecuta cuando la promesa devuelta por fetch, se resuelva correctamente.
            productos = data; // Representa los datos devueltos por el servidor en formato Json
            productos.forEach( // Recorre cada elemento del array: Productos.
                ({ id, imagen, publicadoPor, nombre, precio, descuento }) => crearProducto(id, imagen, publicadoPor, nombre, precio, descuento));// Se llama CraerP con los datos del producto para crear y procesar cada p. individual.
            console.log(productos); // JSON con los productos

        })
        .catch(error => console.error('Error:', error));
    // Manejador de errores
}
function agregarCatalogo1() {
    var productos = "";//Cadena vacia//
    fetch('http://localhost:3000/consultar_productos')//Solicitud al servidor local
        .then(response => { // Función de devolución de llamada, se ejecuta cuando la solicitud a la url se completa con exito.
            if (!response.ok) { // Si la solicitud fue exitosa, si la propiedad ok de la respuesta es falsa arroja msj
                throw new Error('No se pudo completar la solicitud');
            }
            return response.json();// Si la solicitud fue exitosa, convierte la respuesta en JSON, intercambio de datos, envia y recibe datos entre el servidor y cliente.
        })
        .then(data => { // Manejador de exito (callback) se ejecuta cuando la promesa devuelta por fetch, se resuelva correctamente.
            productos = data; // Representa los datos devueltos por el servidor en formato Json
            productos.forEach( // Recorre cada elemento del array: Productos.
                ({ id, imagen, publicadoPor, nombre, precio, descuento }) => crearProducto1(id, imagen, publicadoPor, nombre, precio, descuento));// Se llama CraerP con los datos del producto para crear y procesar cada p. individual.
            console.log(productos); // JSON con los productos

        })
        .catch(error => console.error('Error:', error));
    // Manejador de errores
}

function almacenarIdProducto(idProducto) {// Función con un parametro.
    localStorage.setItem('idProducto', idProducto);// Se almacena , bajo clave.
}

// Función para agregar el producto
function crearProducto(id, imagePath, brand, name, price, discount) {

    // Contenedor del producto
    const contenedorProducto = document.createElement("div");// Crea un elemento div y lo almacena en la const
    contenedorProducto.classList.add('producto', 'd-flex', 'flex-column', 'col-6', 'col-sm-6', 'col-md-3', 'col-lg-3', 'col-xl-2', 'align-items-center'); // Aplica multiples clases de CSS.

    // Imagen
    const imagen = document.createElement("img"); // Crea un elemento img y lo alamacena en la const
    imagen.classList.add('img-fluid'); // Img responsiva
    imagen.setAttribute('src', imagePath); // Estable un atributo, llamado src, con el valor de la url
    imagen.setAttribute('alt', name); // Nombre
    imagen.setAttribute('width', 140); // Ancho
    imagen.setAttribute('height', 170); // Alto

    // Contenedor de la descripcion
    const contenedorDescripcion = document.createElement("div");
    contenedorDescripcion.classList.add('descripcion', 'd-flex', 'flex-column', 'align-items-center');// Aplica multiples clases de CSS.

    // Publicado Por
    const publicadoPor = document.createElement("h2");
    const contenidopublicadoPor = document.createTextNode(brand.toUpperCase());// Crea un nodo de brand, marca y/o publicado por, en mayuscula.
    publicadoPor.appendChild(contenidopublicadoPor);
    // Agrega un nodo como hijo de otro nodo.

    // Nombre de producto
    const producto = document.createElement("p");
    producto.addEventListener('click', () => almacenarIdProducto(id));// Para ese elemento agrege un evento al escuchar clic y ejecute la función.

    const enlaceDetalleDesdeProducto = document.createElement("a");// Enlace
    const contenidoProducto = document.createTextNode(name);
    enlaceDetalleDesdeProducto.append(contenidoProducto);// Añade el nodo de texto
    enlaceDetalleDesdeProducto.setAttribute('href', './detalle_pagina'); // Establece la URL a la que dirije el enlace
    producto.appendChild(enlaceDetalleDesdeProducto);// Agrega un nodo como hijo de otro nodo.

    // Precio original
    const contenedorPrecioOriginal = document.createElement("p");
    const contenidoPrecio = document.createTextNode(`$ ${price}`);// Precio 
    contenedorPrecioOriginal.append(contenidoPrecio);// Añade

    // Precio actual
    const contenedorPrecioActual = document.createElement("p");// Precio actual
    const etiquetaPrecio = document.createElement("span");
    const precioActual = document.createElement("span");

    // Contenido
    const contenidoEtiquetaPrecio = document.createTextNode("Precio");// Crea un nuevo nodo de texto: span y le agrega la palabra Precio en pantalla
    const contenidoPrecioActual = document.createTextNode(`$ ${Math.round((1 - discount) * price)}`);// Crea un nuevo nodo de texto, redondea el descuento del 1% al precio.

    // Añadir el contenido
    etiquetaPrecio.appendChild(contenidoEtiquetaPrecio);// Agrega un nodo como hijo de otro nodo.
    precioActual.appendChild(contenidoPrecioActual);
    contenedorPrecioActual.append(etiquetaPrecio, precioActual);// Añade

    // Agregar contenedor para ver detalle
    const contenedorVerDetalle = document.createElement("p");
    contenedorVerDetalle.addEventListener('click', () => almacenarIdProducto(id));

    // Ver detalle
    const enlaceDetalle = document.createElement("a");
    enlaceDetalle.setAttribute('href', './detalle_pagina');
    enlaceDetalle.setAttribute('data-bs-toggle', 'tooltip');
    enlaceDetalle.setAttribute('data-bs-placement', 'top');
    enlaceDetalle.setAttribute('title', 'Ver producto');

    const iconInfo = document.createElement("i");
    iconInfo.classList.add('bi', 'bi-info-circle');// Agrega las clases CSS.
    iconInfo.style.color = 'black';
    enlaceDetalle.append(iconInfo);// Añade

    contenedorVerDetalle.append(enlaceDetalle);

    // Añadir elementos a body
    contenedorDescripcion.append(contenedorVerDetalle, publicadoPor, producto, contenedorPrecioOriginal, contenedorPrecioActual)
    contenedorProducto.append(imagen, contenedorDescripcion);
    filaCatalogoProd.append(contenedorProducto);
}

function crearProducto1(id, imagePath, brand, name, price, discount) {

    // Contenedor del producto
    const contenedorProducto = document.createElement("div");// Crea un elemento div y lo almacena en la const
    contenedorProducto.classList.add('producto', 'd-flex', 'flex-column', 'col-6', 'col-sm-6', 'col-md-3', 'col-lg-3', 'col-xl-2', 'align-items-center'); // Aplica multiples clases de CSS.

    // Imagen
    const imagen = document.createElement("img"); // Crea un elemento img y lo alamacena en la const
    imagen.classList.add('img-fluid'); // Img responsiva
    imagen.setAttribute('src', imagePath); // Estable un atributo, llamado src, con el valor de la url
    imagen.setAttribute('alt', name); // Nombre
    imagen.setAttribute('width', 140); // Ancho
    imagen.setAttribute('height', 170); // Alto

    // Contenedor de la descripcion
    const contenedorDescripcion = document.createElement("div");
    contenedorDescripcion.classList.add('descripcion', 'd-flex', 'flex-column', 'align-items-center');// Aplica multiples clases de CSS.

    // Publicado Por
    const publicadoPor = document.createElement("h2");
    const contenidopublicadoPor = document.createTextNode(brand.toUpperCase());// Crea un nodo de brand, marca y/o publicado por, en mayuscula.
    publicadoPor.appendChild(contenidopublicadoPor);
    // Agrega un nodo como hijo de otro nodo.

    // Nombre de producto
    const producto = document.createElement("p");
    producto.addEventListener('click', () => almacenarIdProducto(id));// Para ese elemento agrege un evento al escuchar clic y ejecute la función.

    const enlaceDetalleDesdeProducto = document.createElement("a");// Enlace
    const contenidoProducto = document.createTextNode(name);
    enlaceDetalleDesdeProducto.append(contenidoProducto);// Añade el nodo de texto
    enlaceDetalleDesdeProducto.setAttribute('href', './detalle'); // Establece la URL a la que dirije el enlace
    producto.appendChild(enlaceDetalleDesdeProducto);// Agrega un nodo como hijo de otro nodo.

    // Precio original
    const contenedorPrecioOriginal = document.createElement("p");
    const contenidoPrecio = document.createTextNode(`$ ${price}`);// Precio 
    contenedorPrecioOriginal.append(contenidoPrecio);// Añade

    // Precio actual
    const contenedorPrecioActual = document.createElement("p");// Precio actual
    const etiquetaPrecio = document.createElement("span");
    const precioActual = document.createElement("span");

    // Contenido
    const contenidoEtiquetaPrecio = document.createTextNode("Precio");// Crea un nuevo nodo de texto: span y le agrega la palabra Precio en pantalla
    const contenidoPrecioActual = document.createTextNode(`$ ${Math.round((1 - discount) * price)}`);// Crea un nuevo nodo de texto, redondea el descuento del 1% al precio.

    // Añadir el contenido
    etiquetaPrecio.appendChild(contenidoEtiquetaPrecio);// Agrega un nodo como hijo de otro nodo.
    precioActual.appendChild(contenidoPrecioActual);
    contenedorPrecioActual.append(etiquetaPrecio, precioActual);// Añade

    // Agregar contenedor para ver detalle
    const contenedorVerDetalle = document.createElement("p");
    contenedorVerDetalle.addEventListener('click', () => almacenarIdProducto(id));

    // Ver detalle
    const enlaceDetalle = document.createElement("a");
    enlaceDetalle.setAttribute('href', './detalle');
    enlaceDetalle.setAttribute('data-bs-toggle', 'tooltip');
    enlaceDetalle.setAttribute('data-bs-placement', 'top');
    enlaceDetalle.setAttribute('title', 'Ver producto');

    const iconInfo = document.createElement("i");
    iconInfo.classList.add('bi', 'bi-info-circle');// Agrega las clases CSS.
    iconInfo.style.color = 'black';
    enlaceDetalle.append(iconInfo);// Añade

    contenedorVerDetalle.append(enlaceDetalle);

    // Añadir elementos a body
    contenedorDescripcion.append(contenedorVerDetalle, publicadoPor, producto, contenedorPrecioOriginal, contenedorPrecioActual)
    contenedorProducto.append(imagen, contenedorDescripcion);
    filaCatalogoProd.append(contenedorProducto);
}

//Funcion para buscar producto

function buscarMostrarProducto() {

    const productosPorBusqueda = productos1.filter((producto) => producto.nombre.toLowerCase().includes(inputBuscar.value.toLowerCase()));//Filtrado producto, nombre en minusculas, incluyendo la busqueda del usuario, y devuelve un array con el producto que coincide con la busqueda.
    const cantidadProductosPorBusqueda = productos1.filter((producto) => producto.nombre.toLowerCase().includes(inputBuscar.value.toLowerCase())).length;
    //Número total de productos que coinciden con la busqueda.

    if (!cantidadProductosPorBusqueda) {
        alert('No se encontraron productos');

    } else {
        filaCatalogoProd.innerHTML = '';// Limpia el contenido del elemento
        productosPorBusqueda.forEach( // Recorre cada uno de los productos encontrados y llama a la función
            ({ id, imagen, publicadoPor, nombre, precio, descuento }) => crearProducto(id, imagen, publicadoPor, nombre, precio, descuento));
    }
}

//Validaciòn de login

function validarLogin() {
    event.preventDefault();// Evento que evita que la pagina recargue

    var usuarios = "";
    let usuariosFiltrado = "";
    let validacion = 0;
    fetch('http://localhost:3000/consultar_usuario')//Solicitud al servidor local
        .then(response => {// Función de devolución de llamada, se ejecuta cuando la solicitud a la url se completa con exito.
            if (!response.ok) {// Si la solicitud fue exitosa, si la propiedad ok de la respuesta es falsa arroja msj
                throw new Error('No se pudo completar la solicitud');
            }
            return response.json();// Si la solicitud fue exitosa, convierte la respuesta en JSON, intercambio de datos, envia y recibe datos entre el servidor y cliente.
        })
        .then(data => {
            usuarios = data;
            //validar los datos del usuario antes de enviar el formulario al servidor//
            let valorCorreo = inputCorreoLogin.value;// Capturando los datos del form.
            let valorContrasena = inputContrasenaLogin.value;
            usuarios.forEach(({ email, password }) => {
                if (email == valorCorreo && password == valorContrasena) {
                    console.log('Login validado');
                    usuariosFiltrado = valorCorreo;
                    console.log(usuariosFiltrado);
                    localStorage.setItem('usuarios', JSON.stringify(usuariosFiltrado)); // Si el inicio de sesión es válido, se almacenan los datos del usuario, en el almacenamiento local del navegador bajo la clave 'usuarios' (objeto a cadena).
                    location.href = 'pagina';
                    validacion = 1;
                }
            });
            console.log(validacion);
            if (validacion == 0) {
                alert("Debe ingresar las credenciales correctas");
            }

            console.log(usuarios);

        })
        .catch(error => console.error('Error:', error));
    // Manejador de errores

}
//Validaciòn de login

function validarLoginAdmin() {
    event.preventDefault();// Evento que evita que la pagina recargue
    var usuarios = "";
    let usuariosFiltrado = "";
    let validacion = 0;
    fetch('http://localhost:3000/consultar_usuarioadm')//Solicitud al servidor local
        .then(response => { //Función de devolución de llamada, se ejecuta cuando la solicitud a la url se completa con exito.
            if (!response.ok) {// Si la solicitud fue exitosa, y la propiedad ok de la respuesta es falsa arroja msj:
                throw new Error('No se pudo completar la solicitud');
            }
            return response.json();// Si la solicitud fue exitosa, convierte la respuesta en JSON: intercambio de datos, envia y recibe datos entre el servidor y cliente.
        })
        .then(data => {
            usuarios = data;
            let valorCorreo = inputCorreoLogin.value;//Asigna
            let valorContrasena = inputContrasenaLogin.value;
            usuarios.forEach(({ email, password }) => {
                if (email == valorCorreo && password == valorContrasena) {
                    console.log('Login validado');
                    localStorage.setItem('usuariosadm', JSON.stringify(usuariosFiltrado));// Si el inicio de sesión es válido, se almacenan los datos del usuario, en el almacenamiento local del navegador bajo la clave 'usuariosadm' (objeto a cadena).
                    location.href = 'admin';
                    validacion = 1;
                }
            });
            console.log(validacion);
            if (validacion == 0) {
                alert("Debe ingresar las credenciales correctas");
            }
            console.log(usuarios); // JSON con los usuarios
        })
        .catch(error => console.error('Error:', error));
    //Manejo de errores
}

//Detalle de productos

function agregarDetalleProducto(id) {
    console.log(id);
    var productos = "";
    var producto = "";
    var productoBuscado = "";

    // Primera llamada a fetch para obtener la información del producto
    fetch('http://localhost:3000/consultar_productos')//Solicitud al servidor local
        .then(response => {// Devuelve llamada, y se ejecuta cuando la solicitud a la url se completa con exito.
            if (!response.ok) { // Si la solicitud fue exitosa, y la propiedad ok de la respuesta es falsa arroja msj:
                throw new Error('No se pudo completar la solicitud');
            }
            return response.json();// Si la solicitud fue exitosa, convierte la respuesta en JSON: intercambio de datos, envia y recibe datos entre el servidor y cliente.
        })
        .then(data => {
            productos = data;
            // Filtro del producto por su id
            producto = productos.find(producto => producto.id === parseInt(id));//Busca un elemento especifico en un array por su id, pasa el argumento de cadena a número.
            console.log(producto); // JSON con el producto

            // Llamamos a la segunda función dentro de este bloque
            fetchDetallesProducto(id);
        })
        .catch(error => console.error('Error:', error));
    //Manejo de errores

    // Función para hacer la segunda llamada a fetch para obtener los detalles del producto
    function fetchDetallesProducto(id) {
        var detalleProductos = "";
        fetch('http://localhost:3000/consultar_detalles')//Solicitud al servidor local
            .then(response => { // Devuelve la llamada, y se ejecuta cuando la solicitud a la url, se completa con exito.
                if (!response.ok) { // Si la solicitud fue exitosa, pero la propiedad ok, da como respuesta falso:
                    throw new Error('No se pudo completar la solicitud');
                }
                return response.json(); // Si la solicitud fue exitosa, convierte la respuesta en JSON: Intercambio de datos, envia y recibe datos.
            })
            .then(data => {
                detalleProductos = data;
                // Filtramos los detalles del producto por su id
                productoBuscado = detalleProductos.find(detalle => detalle.id === parseInt(id));//Busca un elemento especifico en un array por su id, pasa el argumento de cadena a número.
                console.log(productoBuscado); // JSON con los detalles del producto.
                // Llamamos a la función para crear el detalle del producto
                const tallas = [{ "talla": productoBuscado.tallas_talla, "cantidad": productoBuscado.tallas_cantidad }];
                crearDetalleProducto(producto.nombre, productoBuscado.precio, productoBuscado.descuento, productoBuscado.descripcion, productoBuscado.tallas_talla, tallas, productoBuscado.rutaImagen, productoBuscado.categoria);
            })
            .catch(error => console.error('Error:', error));
    }
}


function asignarCantidadDisponible(arrayTallas, etiqueta, entrada) {//Parametro que representa un array, cantidad disponible, et: Donde se mostrara la cantidad disponible, ent: ajustar o establecer rango de selección de cantidad dispo.
    let arrayFiltradoPorTalla = arrayTallas.filter(t => t.talla === event.target.value);//Filtro de tallas, para obtener solo el objeto de talla seleccionado.
    etiqueta.textContent = '';// Limpia el contenido, contenido de texto en un nodo, incluye espacios y saltos de linea.
    etiqueta.textContent = arrayFiltradoPorTalla[0].cantidad
        ? `${arrayFiltradoPorTalla[0].cantidad} disponibles`
        : `0 disponibles`;
    entrada.setAttribute('min', '0');
    entrada.setAttribute('max', arrayFiltradoPorTalla[0].cantidad);
    //Contenido del elemento etiqueta, si se encuentra una cantidad disponible para la talla seleccionada, se mostrará esa cantidad. De lo contrario, se mostrará "0 disponibles".

    // Verificar si la cantidad ingresada es mayor que la cantidad disponible
    entrada.addEventListener('input', function () {
        let cantidadIngresada = parseInt(entrada.value);
        if (cantidadIngresada > arrayFiltradoPorTalla[0].cantidad) {
            alert("La cantidad ingresada es mayor que la cantidad disponible, por favor ingrese una cantidad válida.");
            entrada.value = arrayFiltradoPorTalla[0].cantidad; // Establecer el valor máximo disponible
        }
    });

    // Desactivar el campo de entrada si no hay cantidad disponible
    if (!arrayFiltradoPorTalla[0].cantidad) {
        entrada.disabled = true;
    } else {
        entrada.disabled = false;
    }
}

function crearDetalleProducto(nombre, precio, descuento, descripcion, talla, tallas, rutaImagen, categoria) {

    let precioActual = descuento ? `${Math.round((1 - descuento) * precio)}` : precio;

    const contenedorImagenCol = document.createElement('div');
    contenedorImagenCol.classList.add('col-sm-3', 'col-md-3', 'col-lg-3');
    const contenedorImagenFil = document.createElement('div');
    contenedorImagenFil.classList.add('row');

    const contenedorImagen = document.createElement('div');
    contenedorImagen.classList.add('col-12', 'mb-5');
    const etiquetaImagen = document.createElement('img');
    etiquetaImagen.classList.add('img-fluid', 'mx-auto', 'd-block');//Establecer img fluida y ajuste al contenedor, centrar horizontalmente, bloque en linea y ocupe el ancho de la img)
    etiquetaImagen.setAttribute('src', rutaImagen);
    etiquetaImagen.setAttribute('width', 260);
    etiquetaImagen.setAttribute('height', 350);
    etiquetaImagen.setAttribute('alt', nombre);//Nombre atributo

    contenedorImagen.append(etiquetaImagen);// Toma un argumento y agrega ese elemento al final del elemento destino.
    contenedorImagenFil.append(contenedorImagen);
    contenedorImagenCol.append(contenedorImagenFil);

    const contenedorDetalle = document.createElement('div');
    contenedorDetalle.classList.add('col-sm-8', 'col-md-8', 'col-lg-6', 'text-center');

    const contenedorCategoria = document.createElement('div');
    contenedorCategoria.classList.add('col', 'col-12');
    const etiquetaCategoria = document.createElement('h2');
    const etiquetaCategoriaValor = document.createTextNode(categoria.toUpperCase());// Crea un nuevo nodo de texto en mayuscula
    etiquetaCategoria.append(etiquetaCategoriaValor);// Agrega ese elemento al final del elemento destino.
    contenedorCategoria.append(etiquetaCategoria);

    const contenedorNombreProducto = document.createElement('div');
    contenedorNombreProducto.classList.add('col', 'col-12');
    const etiquetaNombreProducto = document.createElement('h2');
    const etiquetaNombreProductoValor = document.createTextNode(nombre);
    etiquetaNombreProducto.append(etiquetaNombreProductoValor);
    contenedorNombreProducto.append(etiquetaNombreProducto);

    const contenedorPrecio = document.createElement('div');
    contenedorPrecio.classList.add('col', 'col-12');
    const etiquetaPrecio = document.createElement('h4');
    const etiquetaPrecioValor = document.createTextNode(`$${precioActual}`);
    etiquetaPrecio.append(etiquetaPrecioValor);
    contenedorPrecio.append(etiquetaPrecio);

    const contenedorDescripcion = document.createElement('div');
    contenedorDescripcion.classList.add('col', 'col-12');
    const etiquetaDescripcion = document.createElement('p');
    etiquetaDescripcion.classList.add('text-start');//Alinear texto a la izquierda
    const etiquetaDescripcionValor = document.createTextNode(descripcion);
    etiquetaDescripcion.append(etiquetaDescripcionValor);
    contenedorDescripcion.append(etiquetaDescripcion);

    const contenedorTamano = document.createElement('div');
    contenedorTamano.classList.add('col', 'col-12', 'd-flex', 'pb-3');

    const etiquetaTamano = document.createElement('label');// Formulario
    etiquetaTamano.classList.add('col-3');
    etiquetaTamano.setAttribute('for', 'tamano');
    const etiquetaTamanoValor = document.createTextNode('Ver');
    etiquetaTamano.append(etiquetaTamanoValor);

    const listaTamano = document.createElement('select');// Lista desplegable
    listaTamano.classList.add('form-select', 'rounded-pill');// Selección en formularios y redondea los bordes. 
    listaTamano.setAttribute('id', 'tamano');
    listaTamano.addEventListener('change', () => asignarCantidadDisponible(tallas, etiquetaCantidadDisponible, entradaCarrito));// Cuando se realiza un cambio en el valor seleccionado, cuando ocurre este cambio, se ejecuta la función .

    const opcionPorDefecto = document.createElement('option');// Opción en una lista desplegable.
    opcionPorDefecto.setAttribute('selected', '');
    const opcionPorDefectoValor = document.createTextNode('Elige una opción');
    opcionPorDefecto.append(opcionPorDefectoValor);
    listaTamano.append(opcionPorDefecto);

    let opcion = document.createElement('option');
    opcion.value = talla;
    opcion.textContent = talla;
    listaTamano.append(opcion);

    contenedorTamano.append(etiquetaTamano, listaTamano);

    const division = document.createElement('hr');//Linea horizontal

    const contenedorCantidadDisponible = document.createElement('div');
    contenedorCantidadDisponible.classList.add('col', 'col-12');
    const etiquetaCantidadDisponible = document.createElement('p');
    contenedorCantidadDisponible.append(etiquetaCantidadDisponible);

    const contenedorCarrito = document.createElement('div');
    contenedorCarrito.classList.add('col', 'col-12');
    const entradaCarrito = document.createElement('input');
    entradaCarrito.classList.add('col-2', 'p-2', 'border-0', 'border-bottom');
    entradaCarrito.setAttribute('type', 'number');
    entradaCarrito.setAttribute('id', 'cantidadProductos');
    entradaCarrito.setAttribute('min', '0');
    entradaCarrito.setAttribute('value', '0');
    entradaCarrito.setAttribute('disabled', '');

    const botonCarrito = document.createElement('button');
    botonCarrito.classList.add('col-8', 'border-0', 'p-2', 'rounded-pill', 'btnCarrito');
    botonCarrito.setAttribute('type', 'submit');// Boton de envio de formulario
    const botonCarritoValor = document.createTextNode('Añadir al carrito');
    botonCarrito.append(botonCarritoValor);
    botonCarrito.addEventListener('click', () => {
        let cantidadProductos = document.querySelector('#cantidadProductos').value;// Selección de elemento por su id 
        let tallaSeleccionada = document.querySelector('#tamano').value; //Accede al valor del elemento 
        if (document.querySelector('#tamano').value === 'Elige una opción') {
            alert("Debe elegir un tamaño"); // Campo ver
            return;
        }
        if (cantidadProductos == 0) {
            alert("Debe elegir una cantidad mayor a cero");
            return;
        }
        alert('Se añadio al carrito: ' + nombre);

        agregarProductoAlCarrito(nombre, tallaSeleccionada, precioActual, cantidadProductos);
    }

    );

    contenedorCarrito.append(entradaCarrito, botonCarrito);
    contenedorDetalle.append(contenedorCategoria, contenedorNombreProducto, contenedorPrecio, contenedorDescripcion, contenedorTamano, division, contenedorCantidadDisponible, contenedorCarrito);
    contenedor.append(contenedorImagenCol, contenedorDetalle);
}

//Carrito de compras


function agregarProductoAlCarrito(nombre, tallaSeleccionada, precio, cantidadProductos) {
    let carrito = [];
    const productoSeleccionado = {
        nombre,
        tallaSeleccionada,
        precio,
        cantidadProductos
    };

    localStorage.setItem('productoSeleccionado', JSON.stringify(productoSeleccionado));//  Se almacenan los datos del producto seleccionado, en el almacenamiento local del navegador bajo la clave 'productoSeleccionado' (objeto a cadena).

    if (JSON.parse(localStorage.getItem('productoSeleccionado')) !== null) {
        obj = JSON.parse(localStorage.getItem('productoSeleccionado'));
        console.log(obj);
        // Se valida si hay un elemento almacenado en el localStorage bajo la clave ProdS, devuelva el valor almacenado, este se devuelve en cadena, conviertalo de nuevo en objeto; si el resultado es null, significa que hay un elemento almacenado.
        if (!JSON.parse(localStorage.getItem('carrito'))) {
            carrito.push(obj);// Se valida si no hay algun elemento almacenado en LocalStorage bajo la clave carrito, si es así se agrega el objeto al array carrito.
        } else {
            carrito = JSON.parse(localStorage.getItem('carrito'));
            carrito.push(obj); // Si hay elementos almacenados en el localStorage, bajo la clave, se recuperan los elementos, y se convierte en un array y se almacena en la variable Carrito, y luego se agrega el obj al array carrito.
        }

        localStorage.setItem('carrito', JSON.stringify(carrito));// Almacena el contenido array, carrito, en el almacenamiento local del navegador bajo clave, pero antes conviertalo en cadena.
    }

    console.log('Se añadio al carrito ');
}

function calcularTotal() {
    let precios = [];// Array vacio, almacenar los precios calculados de cada producto
    carrito = JSON.parse(localStorage.getItem('carrito'));// Recupere el contenido del carrito almacenado en el localStorage y se convierte de nuevo en un array.
    carrito.forEach(({ precio, cantidadProductos }) => {
        let precioCalculado = precio * cantidadProductos;
        precios.push(precioCalculado);
    });// Se itera sobre cada elemento del carrito y se calcula el costo total y se almacena en un array precios.
    let total = precios.reduce(getSum, 0);// Suma todos los elementos y calcula el costo total; argumento para realizar la operación.
    function getSum(total, num) { // Se defince la función, con dos parametros, el acumulador de la suma parcial y num el elemento actual del array.
        return parseInt(total) + parseInt(num);//Convierte los valores a enteros antes de sumarlos.
    }
    return total;// Se devuelve el costo total calculado.
}

function calcularCantidadTotal() {
    let carrito = [];// Array vacio
    let cantidades = [];
    carrito = JSON.parse(localStorage.getItem('carrito'));// Recupere el contenido del carrito almacenado en el localStorage y se convierte de nuevo en un array.
    if (!carrito) {
        return 0;
        //Si el carrito está vacío o no definido, la función devuelve 0 como cantidad total de productos.
    } else {
        carrito.forEach(({ cantidadProductos }) => {
            cantidades.push(cantidadProductos);
        });
        // Se itera sobre cada elemento del carrito, Para cada elemento del carrito, se desestructura la propiedad cantidadProductos y se agrega al array cantidades.
        let total = cantidades.reduce(getSum, 0);// Suma todos los elementos y calcula el costo total; argumento para realizar la operación.
        function getSum(total, num) { // Se defince la función, con dos parametros, el acumulador de la suma parcial y num el elemento actual del array.
            return parseInt(total) + parseInt(num); //Convierte los valores a enteros antes de sumarlos.
        }
        return total;// Se devuelve el costo total calculado.
    }
}

function renderizarCarrito() {

    const contenedorProductosDeCarrito = document.createElement('div');
    contenedorProductosDeCarrito.classList.add('col');

    const tablaProductos = document.createElement('table');// Tabla
    tablaProductos.classList.add('table');

    const tablaEncabezado = document.createElement('thead');// Tabla encabezado

    const tablaFilaEncabezado = document.createElement('tr'); //Columnas

    const tablaFilaProducto = document.createElement('th');// Filas
    tablaFilaProducto.setAttribute('scope', 'col');// Celdas de encabezado
    tablaFilaProducto.setAttribute('colspan', '2');// Num de columnas
    tablaFilaProducto.textContent = 'PRODUCTO';// Texto que se va a mostrar 

    const tablaFilaPrecio = document.createElement('th');
    tablaFilaPrecio.setAttribute('scope', 'col');
    tablaFilaPrecio.textContent = 'PRECIO';

    const tablaFilaCantidad = document.createElement('th');
    tablaFilaCantidad.setAttribute('scope', 'col');
    tablaFilaCantidad.textContent = 'CANTIDAD';

    const tablaFilaTotal = document.createElement('th');
    tablaFilaTotal.setAttribute('scope', 'col');
    tablaFilaTotal.textContent = 'TOTAL';

    tablaFilaEncabezado.append(tablaFilaProducto, tablaFilaPrecio, tablaFilaCantidad, tablaFilaTotal);
    tablaEncabezado.append(tablaFilaEncabezado);

    const tablaCuerpo = document.createElement('tbody'); // Cuerpo de tabla        
    carrito = JSON.parse(localStorage.getItem('carrito'));// Recupere el contenido del carrito almacenado en el localStorage y se convierte de nuevo en un array.
    carrito.forEach(({ nombre, precio, cantidadProductos }) => {

        const tablaFilaCuerpo = document.createElement('tr');
        const tablaFilaBotonEliminar = document.createElement('td');
        const BotonEliminar = document.createElement('input');
        BotonEliminar.classList.add('btn', 'btn-ligth', 'rounded-circle');
        BotonEliminar.setAttribute('type', 'button');
        BotonEliminar.setAttribute('value', '🗑️');
        tablaFilaBotonEliminar.append(BotonEliminar);
        tablaFilaBotonEliminar.addEventListener('click', () => {
            let indice = carrito.findIndex(({ nombre }) => nombre === nombre);//para encontrar el índice del elemento del carrito que tiene el mismo nombre que el producto que se está intentando eliminar
            carrito.splice(indice, 1);//Una vez que se encuentra el índice del producto en el carrito, se elimina ese elemento del array, numero de elementos a eliminar.
            localStorage.setItem('carrito', JSON.stringify(carrito));//Se actualiza el almacenamiento local con el nuevo contenido del carrito después de eliminar el producto
            console.log(JSON.parse(localStorage.getItem('carrito')));
            console.log('Eliminar producto' + nombre);
            location.reload();//  Se recarga la página para reflejar los cambios en la interfaz de usuario después de eliminar el producto del carrito.
        });

        const tablaFilaNombreProducto = document.createElement('th');
        tablaFilaNombreProducto.setAttribute('scope', 'row');
        tablaFilaNombreProducto.textContent = nombre;
        const tablaPrecioUnitario = document.createElement('td');
        tablaPrecioUnitario.textContent = precio;
        const tablaCantidadProductos = document.createElement('td');
        tablaCantidadProductos.textContent = cantidadProductos;
        const tablaPrecioTotal = document.createElement('td');
        tablaPrecioTotal.textContent = `${parseInt(cantidadProductos) * parseInt(precio)}`;

        tablaFilaCuerpo.append(tablaFilaBotonEliminar, tablaFilaNombreProducto, tablaPrecioUnitario, tablaCantidadProductos, tablaPrecioTotal);
        tablaCuerpo.append(tablaFilaCuerpo); //Se añade la fila de cuerpo a la tabla (el cuerpo de la tabla). Esto completa la fila que representa un producto en el carrito.
    });

    const contenedorPrecioProductosDeCarrito = document.createElement('div');
    contenedorPrecioProductosDeCarrito.classList.add('col');

    const tablaResumen = document.createElement('table');
    tablaResumen.classList.add('table');

    const tablaResumenEncabezado = document.createElement('thead');

    const tablaFilaResumenEncabezado = document.createElement('tr');

    const tablaColumnaResumenEncabezado = document.createElement('th');
    tablaColumnaResumenEncabezado.setAttribute('scope', 'col');// Encabezado
    tablaColumnaResumenEncabezado.setAttribute('colspan', '2');// Número de columnas
    tablaColumnaResumenEncabezado.textContent = 'TOTAL DEL CARRITO';

    tablaResumenEncabezado.append(tablaFilaResumenEncabezado);
    tablaFilaResumenEncabezado.append(tablaColumnaResumenEncabezado);

    const tablaResumenCuerpo = document.createElement('tbody');// Cuerpo de tbla
    const tablaFilaResumen = document.createElement('tr');
    const tablaColumnaResumen = document.createElement('th');
    tablaColumnaResumen.setAttribute('scope', 'row');
    tablaColumnaResumen.textContent = 'Subtotal';

    const tablaColumna2Resumen = document.createElement('td');//Representar una celda de datos
    tablaColumna2Resumen.textContent = `$ ${calcularTotal()}`;

    tablaResumenCuerpo.append(tablaFilaResumen);
    tablaFilaResumen.append(tablaColumnaResumen, tablaColumna2Resumen);
    tablaResumen.append(tablaResumenEncabezado, tablaResumenCuerpo);

    const contenedorBotonFinalizarCompra = document.createElement('div');
    contenedorBotonFinalizarCompra.classList.add('col-5', 'btn', 'btn-outline-success', 'text-center', 'align-items-center');
    contenedorBotonFinalizarCompra.addEventListener('click', () => {
        event.preventDefault();// Evento que evita que la pagina recargue
        let val_usuario = JSON.parse(localStorage.getItem('.usuariosFiltrado'));
        console.log(val_usuario);
        if (JSON.parse(localStorage.getItem('.usuariosFiltrado'))) {
            location.href = './login';

        } else {
            location.href = './datos-facturacion';
        }
        console.log(calcularTotal());
        console.log('finalizar compra')
    })
    const enlaceBotonFinalizarCompra = document.createElement('a');
    enlaceBotonFinalizarCompra.setAttribute('href', '');
    enlaceBotonFinalizarCompra.textContent = 'FINALIZAR COMPRA';
    contenedorBotonFinalizarCompra.append(enlaceBotonFinalizarCompra);

    const contenedorBotonSeguirComprando = document.createElement('div');
    contenedorBotonSeguirComprando.classList.add('col-6', 'btn', 'btn-outline-success', 'text-center', 'align-items-center', 'm-1');

    contenedorBotonSeguirComprando.addEventListener('click', () => {
        event.preventDefault();// Evento que evita que la pagina recargue
        if (!JSON.parse(localStorage.getItem('.usuarios'))) {
            location.href = './index';
        } else {
            location.href = './pagina';
        }
    })

    const enlaceBotonSeguirComprando = document.createElement('a');
    enlaceBotonSeguirComprando.setAttribute('href', location.origin + '');
    enlaceBotonSeguirComprando.textContent = 'SEGUIR COMPRANDO';
    contenedorBotonSeguirComprando.append(enlaceBotonSeguirComprando);

    tablaProductos.append(tablaEncabezado, tablaCuerpo);
    contenedorProductosDeCarrito.append(tablaProductos);
    contenedorPrecioProductosDeCarrito.append(tablaResumen, contenedorBotonSeguirComprando, contenedorBotonFinalizarCompra);

    contenedorCarritoPrincipal.append(contenedorProductosDeCarrito, contenedorPrecioProductosDeCarrito);
}

function paginaCarrito() {
    if (!calcularCantidadTotal()) {
        const mensajeCarritoVacio = document.createElement('div');
        mensajeCarritoVacio.textContent = 'Carrito vacio';
        contenedorCarritoPrincipal.append(mensajeCarritoVacio);
    } else {
        renderizarCarrito();
    }
}

//Pago//

document.addEventListener("DOMContentLoaded", function () {
    var inputNumeroTarjeta = document.getElementById("numeroTarjeta");

    inputNumeroTarjeta.addEventListener("input", function () {
        // Eliminar cualquier caracter que no sea un dígito
        this.value = this.value.replace(/\D/g, '');

        // Verificar si la longitud actual del valor es mayor que 16
        if (this.value.length > 16) {
            // Si es mayor, truncar a 16 caracteres
            this.value = this.value.slice(0, 16);
        }
    });
});

// Crear el enlace de detalle
const enlaceDetalle = document.createElement("a");
enlaceDetalle.setAttribute('href', './detalle.html'); // Establecer el destino del enlace
enlaceDetalle.setAttribute('data-bs-toggle', 'tooltip'); // Configurar el tooltip
enlaceDetalle.setAttribute('data-bs-placement', 'top'); // Configurar la posición del tooltip
enlaceDetalle.setAttribute('title', 'Ver producto'); // Configurar el título del tooltip

// Crear el icono de información dentro del enlace
const iconInfo = document.createElement("i");
iconInfo.classList.add('bi', 'bi-info-circle'); // Agregar clases para el icono de Bootstrap
iconInfo.style.color = 'black'; // Establecer el color del icono
enlaceDetalle.append(iconInfo); // Agregar el icono al enlace

// Supongamos que contenedorVerDetalle es algún contenedor en tu página HTML
const contenedorVerDetalle = document.getElementById("contenedorVerDetalle"); // Obtener el contenedor por su ID

// Agregar el enlace al contenedor contenedorVerDetalle
contenedorVerDetalle.append(enlaceDetalle);


