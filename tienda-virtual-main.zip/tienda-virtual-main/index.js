//Conexión, sistema de ruta del servidor, base de datos
const express = require('express');//Servidor
const app = express();//Servidor
const path = require('path'); //Sistema de ruta y directorio
const fs = require('fs');//Sistema de ruta y directorio
const mysql = require('mysql');// Base de datos
const bodyParser = require('body-parser'); // Recibir parametros, sistema de ruta
const port = 3000;


// Configurar body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));//Activar recepción de parametros de sistema de ruta
app.use(bodyParser.json());// Para que se pueda leer

// Configuración de parametros para conectar con mysql
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'greensoftworld'
});

connection.connect((err) => { //Errores
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        return;
    }
    console.log('Conexión exitosa a la base de datos MySQL');
});


// Define una ruta para consultar los productos de la base de datos
app.get('/consultar_productos', (req, res) => { // Transformación de pagina estatica a sistema de ruta

    // Consulta SQL para obtener todos los productos
    const sql = 'SELECT * FROM productos';
        
    // Ejecutar la consulta SQL
    connection.query(sql, (error, results, fields) => {
        if (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al consultar la base de datos');
        return;
        }
        
        // Devolver los resultados como JSON
        res.json(results);
    });  
    
    
});

// Define una ruta para consultar los usuarios de la base de datos
app.get('/consultar_usuario', (req, res) => {

    // Consulta SQL para obtener todos los productos
    const sql = 'SELECT * FROM usuarios';
        
    // Ejecutar la consulta SQL
    connection.query(sql, (error, results, fields) => {
        if (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al consultar la base de datos');
        return;
        }
        
        // Devolver los resultados como JSON
        res.json(results);
    });  
    
    
});

// Define una ruta para consultar los usuarios admin de la base de datos
app.get('/consultar_usuarioadm', (req, res) => {

    // Consulta SQL para obtener todos los productos
    const sql = 'SELECT * FROM usuarios where perfil = "ADMIN"';
        
    // Ejecutar la consulta SQL
    connection.query(sql, (error, results, fields) => {
        if (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al consultar la base de datos');
        return;
        }
        
        // Devolver los resultados como JSON
        res.json(results);
    });  
    
    
});

// Define una ruta para consultar los detalles productos de la base de datos
app.get('/consultar_detalles', (req, res) => {
    

    // Consulta SQL para obtener todos los productos
    const sql = 'SELECT * FROM detalles_productos';
        
    // Ejecutar la consulta SQL
    connection.query(sql, (error, results, fields) => {
        if (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al consultar la base de datos');
        return;
        }
        
        // Devolver los resultados como JSON
        res.json(results);
    });  
    
    
});

// Ruta para agregar un producto
app.post('/agregar_producto', (req, res) => {
    console.log(req.body);
    const { publicadoPor, nombre, precio, descuento, imagen, descripcion, categoria } = req.body;
  
    // Insertar el producto en la base de datos
    const sql = `INSERT INTO productos (publicadoPor, nombre, precio, descuento, imagen) VALUES (?, ?, ?, ?, ?)`;
    connection.query(sql, [publicadoPor, nombre, precio, descuento, imagen], (err, result) => {
      if (err) {
        console.error('Error al insertar el producto:', err);
        res.status(500).send('Error al insertar el producto en la base de datos');
        return;
      }
      console.log('Producto insertado correctamente');
    });

    // Insertar el detalle del producto en la base de datos
    const sql1 = `INSERT INTO detalles_productos (marca, precio, descuento, tallas_talla, tallas_cantidad, rutaImagen, descripcion, categoria) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    connection.query(sql1, ["Propia", precio, descuento, "Cantidad disponible", 30, imagen, descripcion, categoria], (err, result) => {
        if (err) {
          console.error('Error al insertar el producto:', err);
          res.status(500).send('Error al insertar el producto en la base de datos');
          return;
        }
        console.log('Producto insertado correctamente');
        res.status(200).send('Producto insertado correctamente');
      });
  });

// Ruta para agregar un usuario
app.post('/agregar_vendedor', (req, res) => {
    console.log(req.body);
    const { email, password, perfil } = req.body;
  
    // Insertar el producto en la base de datos
    const sql = `INSERT INTO usuarios (email, password, perfil, estado) VALUES (?, ?, ?, ?)`;
    connection.query(sql, [email, password, perfil, 1], (err, result) => {
      if (err) {
        console.error('Error al insertar el producto:', err);
        res.status(500).send('Error al insertar el producto en la base de datos');
        return;
      }
      console.log('usuario insertado correctamente');
      res.status(200).send('Producto insertado correctamente');
    });
});

// // Define una ruta para consultar los usuarios a listar de la base de datos
app.get('/consultar_usuarios', (req, res) => {
    // Consulta SQL para obtener todos los productos
    const sql = 'SELECT * FROM usuarios';
        
    // Ejecutar la consulta SQL
    connection.query(sql, (error, results, fields) => {
        if (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al consultar la base de datos');
        return;
        }
        
        // Devolver los resultados como JSON
        res.json(results);
    });  
});

// Configuración para servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));//Css, img, js, scripts

// Define una ruta para servir el archivo index
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Define una ruta para servir el archivo index
app.get('/index', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Define una ruta para servir el archivo usuarios_registrados
app.get('/usuarios', (req, res) => {
    res.sendFile(path.join(__dirname, 'usuarios_registrados.html'));
});

// Define una ruta para servir el archivo login
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Define una ruta para servir el archivo login-admin
app.get('/login-admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'login-admin.html'));
});

// Define una ruta para servir el archivo pagina
app.get('/pagina', (req, res) => {
    res.sendFile(path.join(__dirname, 'pagina.html'));
});

// Define una ruta para servir el archivo admin
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Define una ruta para servir el archivo carrito
app.get('/carrito', (req, res) => {
    res.sendFile(path.join(__dirname, 'carrito.html'));
});

// Define una ruta para servir el archivo continuarPago
app.get('/continuarPago', (req, res) => {
    res.sendFile(path.join(__dirname, 'continuarPago.html'));
});

// Define una ruta para servir el archivo crear-cuenta
app.get('/crear-cuenta', (req, res) => {
    res.sendFile(path.join(__dirname, 'crear-cuenta.html'));
});

// Define una ruta para servir el archivo datos-facturacion
app.get('/datos-facturacion', (req, res) => {
    res.sendFile(path.join(__dirname, 'datos-facturacion.html'));
});

// Define una ruta para servir el archivo detalle
app.get('/detalle', (req, res) => {
    res.sendFile(path.join(__dirname, 'detalle.html'));
});

// Define una ruta para servir el archivo detalle
app.get('/detalle_pagina', (req, res) => {
    res.sendFile(path.join(__dirname, 'detalle_pagina.html'));
});

// Define una ruta para servir el archivo inventario
app.get('/inventario', (req, res) => {
    res.sendFile(path.join(__dirname, 'inventario.html'));
});

// Define una ruta para servir el archivo pago
app.get('/pago', (req, res) => {
    res.sendFile(path.join(__dirname, 'pago.html'));
});

// Define una ruta para servir el archivo pedidos-usuario
app.get('/pedidos-usuario', (req, res) => {
    res.sendFile(path.join(__dirname, 'pedidos-usuario.html'));
});

// Define una ruta para servir el archivo prueba
app.get('/prueba', (req, res) => {
    res.sendFile(path.join(__dirname, 'prueba.html'));
});

// Define una ruta para servir el archivo vendedor
app.get('/vendedor', (req, res) => {
    res.sendFile(path.join(__dirname, 'vendedor.html'));
});

// Inicia el servidor y escucha en el puerto especificado
app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});
